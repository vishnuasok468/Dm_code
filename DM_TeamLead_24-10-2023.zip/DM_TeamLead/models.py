from django.db import models
from  Registration_Login.models import EmployeeRegister_Details

# Create your models here.
