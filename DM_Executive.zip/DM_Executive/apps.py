from django.apps import AppConfig


class DmExecutiveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DM_Executive'
